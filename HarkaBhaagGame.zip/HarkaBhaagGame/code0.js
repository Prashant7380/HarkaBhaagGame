gdjs.GamesceneCode = {};
gdjs.GamesceneCode.localVariables = [];
gdjs.GamesceneCode.idToCallbackMap = new Map();
gdjs.GamesceneCode.GDBalloonObjects1_1final = [];

gdjs.GamesceneCode.GDBoundaryObjects1_1final = [];

gdjs.GamesceneCode.GDHarkeObjects1_1final = [];

gdjs.GamesceneCode.GDHarkeObjects1= [];
gdjs.GamesceneCode.GDHarkeObjects2= [];
gdjs.GamesceneCode.GDPlatform_9595DirtObjects1= [];
gdjs.GamesceneCode.GDPlatform_9595DirtObjects2= [];
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects1= [];
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects2= [];
gdjs.GamesceneCode.GDPlatform_9595StoneObjects1= [];
gdjs.GamesceneCode.GDPlatform_9595StoneObjects2= [];
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects1= [];
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects2= [];
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects1= [];
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects2= [];
gdjs.GamesceneCode.GDPlatform_9595MovingObjects1= [];
gdjs.GamesceneCode.GDPlatform_9595MovingObjects2= [];
gdjs.GamesceneCode.GDCoinObjects1= [];
gdjs.GamesceneCode.GDCoinObjects2= [];
gdjs.GamesceneCode.GDBalloonObjects1= [];
gdjs.GamesceneCode.GDBalloonObjects2= [];
gdjs.GamesceneCode.GDBoundaryObjects1= [];
gdjs.GamesceneCode.GDBoundaryObjects2= [];
gdjs.GamesceneCode.GDTutorialObjects1= [];
gdjs.GamesceneCode.GDTutorialObjects2= [];
gdjs.GamesceneCode.GDUI_9595ScoreObjects1= [];
gdjs.GamesceneCode.GDUI_9595ScoreObjects2= [];
gdjs.GamesceneCode.GDBackground1Objects1= [];
gdjs.GamesceneCode.GDBackground1Objects2= [];
gdjs.GamesceneCode.GDBackground2Objects1= [];
gdjs.GamesceneCode.GDBackground2Objects2= [];
gdjs.GamesceneCode.GDBackground3Objects1= [];
gdjs.GamesceneCode.GDBackground3Objects2= [];
gdjs.GamesceneCode.GDBackground4Objects1= [];
gdjs.GamesceneCode.GDBackground4Objects2= [];
gdjs.GamesceneCode.GDBackground5Objects1= [];
gdjs.GamesceneCode.GDBackground5Objects2= [];
gdjs.GamesceneCode.GDBackground6Objects1= [];
gdjs.GamesceneCode.GDBackground6Objects2= [];
gdjs.GamesceneCode.GDBackground7Objects1= [];
gdjs.GamesceneCode.GDBackground7Objects2= [];


gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDHarkeObjects1Objects = Hashtable.newFrom({"Harke": gdjs.GamesceneCode.GDHarkeObjects1});
gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.GamesceneCode.GDCoinObjects1});
gdjs.GamesceneCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Platform_Stone"), gdjs.GamesceneCode.GDPlatform_9595StoneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length;i<l;++i) {
    if ( gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[i].isCollidingWithPoint((( gdjs.GamesceneCode.GDBalloonObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBalloonObjects1[0].getPointX("Checker")), (( gdjs.GamesceneCode.GDBalloonObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBalloonObjects1[0].getPointY("Checker"))) ) {
        isConditionTrue_0 = true;
        gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[k] = gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDBalloonObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


};gdjs.GamesceneCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Platform_Stone"), gdjs.GamesceneCode.GDPlatform_9595StoneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length;i<l;++i) {
    if ( gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[i].isCollidingWithPoint((( gdjs.GamesceneCode.GDBalloonObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBalloonObjects1[0].getPointX("Checker")), (( gdjs.GamesceneCode.GDBalloonObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBalloonObjects1[0].getPointY("Checker"))) ) {
        isConditionTrue_0 = true;
        gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[k] = gdjs.GamesceneCode.GDPlatform_9595StoneObjects1[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDBalloonObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


};gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDHarkeObjects2Objects = Hashtable.newFrom({"Harke": gdjs.GamesceneCode.GDHarkeObjects2});
gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDBalloonObjects2Objects = Hashtable.newFrom({"Balloon": gdjs.GamesceneCode.GDBalloonObjects2});
gdjs.GamesceneCode.asyncCallback12250132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GamesceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gamescene", false);
}
gdjs.GamesceneCode.localVariables.length = 0;
}
gdjs.GamesceneCode.idToCallbackMap.set(12250132, gdjs.GamesceneCode.asyncCallback12250132);
gdjs.GamesceneCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GamesceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GamesceneCode.asyncCallback12250132(runtimeScene, asyncObjectsList)), 12250132, asyncObjectsList);
}
}

}


};gdjs.GamesceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4, "", 0);
}
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GamesceneCode.GDHarkeObjects1.length !== 0 ? gdjs.GamesceneCode.GDHarkeObjects1[0] : null), true, "", 0);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "asset pack/time_for_adventure.mp3", 0, false, 40, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Boundary"), gdjs.GamesceneCode.GDBoundaryObjects1);
gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects1);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.GamesceneCode.GDHarkeObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDHarkeObjects1[0].getPointX("")) - 1000, (( gdjs.GamesceneCode.GDHarkeObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDHarkeObjects1[0].getPointY("")) - 1000, (( gdjs.GamesceneCode.GDHarkeObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDHarkeObjects1[0].getPointX("")) + 1000, (( gdjs.GamesceneCode.GDBoundaryObjects1.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBoundaryObjects1[0].getPointY("")), "", 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.GamesceneCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDHarkeObjects1Objects, gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDCoinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDCoinObjects1 */
gdjs.copyArray(runtimeScene.getObjects("UI_Score"), gdjs.GamesceneCode.GDUI_9595ScoreObjects1);
{for(var i = 0, len = gdjs.GamesceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{for(var i = 0, len = gdjs.GamesceneCode.GDUI_9595ScoreObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDUI_9595ScoreObjects1[i].getBehavior("Text").setText("Stone: " + runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "asset pack/khodang.mp3", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Balloon"), gdjs.GamesceneCode.GDBalloonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDBalloonObjects1.length;i<l;++i) {
    if ( gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.GamesceneCode.GDBalloonObjects1[k] = gdjs.GamesceneCode.GDBalloonObjects1[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDBalloonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDBalloonObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}

{ //Subevents
gdjs.GamesceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Balloon"), gdjs.GamesceneCode.GDBalloonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDBalloonObjects1.length;i<l;++i) {
    if ( !(gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.GamesceneCode.GDBalloonObjects1[k] = gdjs.GamesceneCode.GDBalloonObjects1[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDBalloonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDBalloonObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDBalloonObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDBalloonObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}

{ //Subevents
gdjs.GamesceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.GamesceneCode.GDBalloonObjects1.length = 0;

gdjs.GamesceneCode.GDBoundaryObjects1.length = 0;

gdjs.GamesceneCode.GDHarkeObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GamesceneCode.GDBalloonObjects1_1final.length = 0;
gdjs.GamesceneCode.GDBoundaryObjects1_1final.length = 0;
gdjs.GamesceneCode.GDHarkeObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Balloon"), gdjs.GamesceneCode.GDBalloonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDHarkeObjects2Objects, gdjs.GamesceneCode.mapOfGDgdjs_9546GamesceneCode_9546GDBalloonObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GamesceneCode.GDBalloonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GamesceneCode.GDBalloonObjects1_1final.indexOf(gdjs.GamesceneCode.GDBalloonObjects2[j]) === -1 )
            gdjs.GamesceneCode.GDBalloonObjects1_1final.push(gdjs.GamesceneCode.GDBalloonObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GamesceneCode.GDHarkeObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GamesceneCode.GDHarkeObjects1_1final.indexOf(gdjs.GamesceneCode.GDHarkeObjects2[j]) === -1 )
            gdjs.GamesceneCode.GDHarkeObjects1_1final.push(gdjs.GamesceneCode.GDHarkeObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Boundary"), gdjs.GamesceneCode.GDBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects2);
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDHarkeObjects2.length;i<l;++i) {
    if ( gdjs.GamesceneCode.GDHarkeObjects2[i].getY() > (( gdjs.GamesceneCode.GDBoundaryObjects2.length === 0 ) ? 0 :gdjs.GamesceneCode.GDBoundaryObjects2[0].getPointY("")) ) {
        isConditionTrue_1 = true;
        gdjs.GamesceneCode.GDHarkeObjects2[k] = gdjs.GamesceneCode.GDHarkeObjects2[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDHarkeObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GamesceneCode.GDBoundaryObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GamesceneCode.GDBoundaryObjects1_1final.indexOf(gdjs.GamesceneCode.GDBoundaryObjects2[j]) === -1 )
            gdjs.GamesceneCode.GDBoundaryObjects1_1final.push(gdjs.GamesceneCode.GDBoundaryObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GamesceneCode.GDHarkeObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GamesceneCode.GDHarkeObjects1_1final.indexOf(gdjs.GamesceneCode.GDHarkeObjects2[j]) === -1 )
            gdjs.GamesceneCode.GDHarkeObjects1_1final.push(gdjs.GamesceneCode.GDHarkeObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GamesceneCode.GDBalloonObjects1_1final, gdjs.GamesceneCode.GDBalloonObjects1);
gdjs.copyArray(gdjs.GamesceneCode.GDBoundaryObjects1_1final, gdjs.GamesceneCode.GDBoundaryObjects1);
gdjs.copyArray(gdjs.GamesceneCode.GDHarkeObjects1_1final, gdjs.GamesceneCode.GDHarkeObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDHarkeObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDHarkeObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDHarkeObjects1[i].getBehavior("Animation").setAnimationName("Death");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Harke"), gdjs.GamesceneCode.GDHarkeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GamesceneCode.GDHarkeObjects1.length;i<l;++i) {
    if ( gdjs.GamesceneCode.GDHarkeObjects1[i].getBehavior("Animation").getAnimationName() == "Death" ) {
        isConditionTrue_0 = true;
        gdjs.GamesceneCode.GDHarkeObjects1[k] = gdjs.GamesceneCode.GDHarkeObjects1[i];
        ++k;
    }
}
gdjs.GamesceneCode.GDHarkeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12249588);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GamesceneCode.GDHarkeObjects1 */
{for(var i = 0, len = gdjs.GamesceneCode.GDHarkeObjects1.length ;i < len;++i) {
    gdjs.GamesceneCode.GDHarkeObjects1[i].activateBehavior("PlatformerObject", false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "asset pack/balen savage.mp3", false, 100, 1);
}

{ //Subevents
gdjs.GamesceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.GamesceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GamesceneCode.GDHarkeObjects1.length = 0;
gdjs.GamesceneCode.GDHarkeObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595DirtObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595DirtObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595StoneObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595MovingObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595MovingObjects2.length = 0;
gdjs.GamesceneCode.GDCoinObjects1.length = 0;
gdjs.GamesceneCode.GDCoinObjects2.length = 0;
gdjs.GamesceneCode.GDBalloonObjects1.length = 0;
gdjs.GamesceneCode.GDBalloonObjects2.length = 0;
gdjs.GamesceneCode.GDBoundaryObjects1.length = 0;
gdjs.GamesceneCode.GDBoundaryObjects2.length = 0;
gdjs.GamesceneCode.GDTutorialObjects1.length = 0;
gdjs.GamesceneCode.GDTutorialObjects2.length = 0;
gdjs.GamesceneCode.GDUI_9595ScoreObjects1.length = 0;
gdjs.GamesceneCode.GDUI_9595ScoreObjects2.length = 0;
gdjs.GamesceneCode.GDBackground1Objects1.length = 0;
gdjs.GamesceneCode.GDBackground1Objects2.length = 0;
gdjs.GamesceneCode.GDBackground2Objects1.length = 0;
gdjs.GamesceneCode.GDBackground2Objects2.length = 0;
gdjs.GamesceneCode.GDBackground3Objects1.length = 0;
gdjs.GamesceneCode.GDBackground3Objects2.length = 0;
gdjs.GamesceneCode.GDBackground4Objects1.length = 0;
gdjs.GamesceneCode.GDBackground4Objects2.length = 0;
gdjs.GamesceneCode.GDBackground5Objects1.length = 0;
gdjs.GamesceneCode.GDBackground5Objects2.length = 0;
gdjs.GamesceneCode.GDBackground6Objects1.length = 0;
gdjs.GamesceneCode.GDBackground6Objects2.length = 0;
gdjs.GamesceneCode.GDBackground7Objects1.length = 0;
gdjs.GamesceneCode.GDBackground7Objects2.length = 0;

gdjs.GamesceneCode.eventsList3(runtimeScene);
gdjs.GamesceneCode.GDHarkeObjects1.length = 0;
gdjs.GamesceneCode.GDHarkeObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595DirtObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595DirtObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Dirt2Objects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595StoneObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595StoneObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595Stone2Objects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595BridgeObjects2.length = 0;
gdjs.GamesceneCode.GDPlatform_9595MovingObjects1.length = 0;
gdjs.GamesceneCode.GDPlatform_9595MovingObjects2.length = 0;
gdjs.GamesceneCode.GDCoinObjects1.length = 0;
gdjs.GamesceneCode.GDCoinObjects2.length = 0;
gdjs.GamesceneCode.GDBalloonObjects1.length = 0;
gdjs.GamesceneCode.GDBalloonObjects2.length = 0;
gdjs.GamesceneCode.GDBoundaryObjects1.length = 0;
gdjs.GamesceneCode.GDBoundaryObjects2.length = 0;
gdjs.GamesceneCode.GDTutorialObjects1.length = 0;
gdjs.GamesceneCode.GDTutorialObjects2.length = 0;
gdjs.GamesceneCode.GDUI_9595ScoreObjects1.length = 0;
gdjs.GamesceneCode.GDUI_9595ScoreObjects2.length = 0;
gdjs.GamesceneCode.GDBackground1Objects1.length = 0;
gdjs.GamesceneCode.GDBackground1Objects2.length = 0;
gdjs.GamesceneCode.GDBackground2Objects1.length = 0;
gdjs.GamesceneCode.GDBackground2Objects2.length = 0;
gdjs.GamesceneCode.GDBackground3Objects1.length = 0;
gdjs.GamesceneCode.GDBackground3Objects2.length = 0;
gdjs.GamesceneCode.GDBackground4Objects1.length = 0;
gdjs.GamesceneCode.GDBackground4Objects2.length = 0;
gdjs.GamesceneCode.GDBackground5Objects1.length = 0;
gdjs.GamesceneCode.GDBackground5Objects2.length = 0;
gdjs.GamesceneCode.GDBackground6Objects1.length = 0;
gdjs.GamesceneCode.GDBackground6Objects2.length = 0;
gdjs.GamesceneCode.GDBackground7Objects1.length = 0;
gdjs.GamesceneCode.GDBackground7Objects2.length = 0;


return;

}

gdjs['GamesceneCode'] = gdjs.GamesceneCode;
